#pragma once

#include "ppmbin.h"

std::shared_ptr<PPMImage> apply_filter(std::shared_ptr<PPMImage> image);
